const hamburgerBtn = document.getElementById('hamburgerBtn');
const navLinks = document.getElementById('navLinks');
const ddCursos = document.getElementById('ddCursos');

// Toggle menú móvil
hamburgerBtn.addEventListener('click', () => {
  navLinks.classList.toggle('open');
  hamburgerBtn.setAttribute('aria-expanded', navLinks.classList.contains('open'));
});

// Dropdown usable en móvil (tap para abrir/cerrar)
ddCursos.querySelector('.dropdown-toggle').addEventListener('click', (e) => {
  if (window.matchMedia('(max-width: 920px)').matches) {
    e.preventDefault();
    ddCursos.classList.toggle('open');
    ddCursos.querySelector('.dropdown-menu').style.display = ddCursos.classList.contains('open') ? "flex" : "none";
  }
});

// Cerrar menú al navegar en móvil
navLinks.querySelectorAll('a').forEach(a=>{
  a.addEventListener('click', ()=> navLinks.classList.remove('open'));
});

// ===== BUSCAR CURSOS (home) =====
(function () {
  const $input  = document.getElementById('searchInput');
  const $toggle = document.getElementById('searchToggle');
  const $wrap   = document.getElementById('searchWrap');
  const $cards  = document.querySelectorAll('.cursos-grid .curso-card');
  const $grid   = document.querySelector('.cursos-grid');

  if (!$input || !$cards.length) return;

  // Abrir/cerrar buscador
  if ($toggle) {
    $toggle.addEventListener('click', () => {
      $wrap.classList.toggle('open');
      if ($wrap.classList.contains('open')) {
        setTimeout(()=> $input.focus(), 10);
      } else {
        $input.value = '';
        filtrar('');
      }
    });
  }

  // Accesos rápidos: "/" enfoca, ESC cierra
  window.addEventListener('keydown', (e) => {
    if (e.key === '/' && document.activeElement !== $input) {
      e.preventDefault(); $wrap.classList.add('open'); $input.focus();
    } else if (e.key === 'Escape') {
      $wrap.classList.remove('open'); $input.blur(); $input.value=''; filtrar('');
    }
  });

  // Quitar acentos para comparar mejor
  const norm = s => (s || '')
    .toString()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .toLowerCase();

  // Mensaje vacío
  let $empty = null;
  function ensureEmptyNode(){
    if (!$empty) {
      $empty = document.createElement('div');
      $empty.className = 'empty-search';
      $empty.textContent = 'No se encontraron cursos para tu búsqueda.';
      $grid.appendChild($empty);
    }
  }

  // Filtrar
  function filtrar(q){
    const qry = norm(q);
    let visibles = 0;

    $cards.forEach(card => {
      const title = norm(card.querySelector('h3')?.textContent);
      const desc  = norm(card.querySelector('p')?.textContent);
      const hay   = !qry || title.includes(qry) || desc.includes(qry);

      card.style.display = hay ? '' : 'none';
      if (hay) visibles++;
    });

    ensureEmptyNode();
    $empty.style.display = visibles ? 'none' : 'block';
  }

  // Debounce input
  let t=null;
  $input.addEventListener('input', () => {
    clearTimeout(t); t = setTimeout(() => filtrar($input.value), 120);
  });
})();

// ===== Sugerencias con miniaturas (home) =====
(function(){
  const $input  = document.getElementById('searchInput');
  const $toggle = document.getElementById('searchToggle');
  const $wrap   = document.getElementById('searchWrap');
  const $panel  = document.getElementById('searchResults');
  const $cards  = document.querySelectorAll('.cursos-grid .curso-card');

  if (!$input || !$panel || !$cards.length) return;

  // Abrir/cerrar input
  if ($toggle) {
    $toggle.addEventListener('click', () => {
      $wrap.classList.toggle('open');
      if ($wrap.classList.contains('open')) {
        setTimeout(()=> $input.focus(), 10);
      } else {
        closePanel();
      }
    });
  }

  // Construir índice desde las cards existentes
  const norm = s => (s||'').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const items = Array.from($cards).map(card => {
    const title = card.querySelector('h3')?.textContent?.trim() || '';
    const desc  = card.querySelector('p')?.textContent?.trim()  || '';
    const img   = card.querySelector('.curso-media img')?.getAttribute('src') || '';
    const link  = card.querySelector('.btn-cart')?.getAttribute('href') || '#';
    return { title, desc, img, link, _t: norm(title), _d: norm(desc) };
  });

  // Filtrado + render
  let pos = -1; // posición activa en la lista
  let t = null;

  $input.addEventListener('input', () => {
    clearTimeout(t);
    t = setTimeout(() => {
      const q = $input.value.trim();
      if (!q) { closePanel(); return; }
      const nq = norm(q);
      const res = items.filter(it => it._t.includes(nq) || it._d.includes(nq)).slice(0, 6);
      renderResults(res, q);
    }, 120);
  });

  function highlight(text, q){
    if (!q) return text;
    const esc = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return text.replace(new RegExp(esc, 'ig'), m => `<mark>${m}</mark>`);
  }

  function renderResults(list, q){
    if (!list.length) {
      $panel.innerHTML = `<div class="search-empty">No se encontraron cursos para “${q}”.</div>`;
      $panel.classList.add('show'); pos = -1; return;
    }
    $panel.innerHTML = list.map((it,i)=>`
      <a class="search-item" href="${it.link}" data-idx="${i}">
        <span class="search-thumb"><img src="${it.img}" alt=""></span>
        <span class="search-text">
          <h4>${highlight(it.title, q)}</h4>
          <p>${highlight(it.desc, q)}</p>
        </span>
      </a>
    `).join('');
    $panel.classList.add('show'); pos = -1;

    // click fuera cierra
    setTimeout(() => {
      document.addEventListener('click', onDocClick, { once:true });
    }, 0);
  }

  function onDocClick(e){
    if (!$wrap.contains(e.target)) closePanel();
    else document.addEventListener('click', onDocClick, { once:true }); // seguir escuchando hasta click fuera
  }

  function closePanel(){
    $panel.classList.remove('show');
    $panel.innerHTML = '';
    $input.value = '';
    pos = -1;
  }

  // Teclado: / enfoca, Esc cierra, ▲▼ navega, Enter abre
  window.addEventListener('keydown', (e) => {
    if (e.key === '/' && document.activeElement !== $input) {
      e.preventDefault(); $wrap.classList.add('open'); $input.focus(); return;
    }
    if (e.key === 'Escape') { closePanel(); $wrap.classList.remove('open'); $input.blur(); return; }

    if (!$panel.classList.contains('show')) return;
    const $items = Array.from($panel.querySelectorAll('.search-item'));
    if (!$items.length) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      pos = (pos + 1) % $items.length;
      setActive($items, pos);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      pos = (pos - 1 + $items.length) % $items.length;
      setActive($items, pos);
    } else if (e.key === 'Enter' && pos >= 0) {
      e.preventDefault();
      $items[pos].click();
    }
  });

  function setActive(nodes, idx){
    nodes.forEach(n => n.classList.remove('active'));
    const n = nodes[idx];
    if (n) {
      n.classList.add('active');
      n.scrollIntoView({ block: 'nearest' });
    }
  }
})();
